package com.example.bloccubit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
