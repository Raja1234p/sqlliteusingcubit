import 'package:bloccubit/common_component/textfiled_component.dart';
import 'package:bloccubit/constants/string_constants.dart';
import 'package:bloccubit/cubit/authenticate_user_cubit.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailEditingController = TextEditingController();
  final TextEditingController passwordEditingController =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(StringConstants.title),
        centerTitle: true,
      ),
      body: SafeArea(
          child: BlocConsumer<RegisterUserCubit, RegisterUserState>(
              listener: (context, state) {
        switch (state) {
          case RegisterUserState.success:
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Account created'),
              ),
            );
            break;
          case RegisterUserState.user_not_exist:
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('user not exist'),
              ),
            );
            break;
          case RegisterUserState.password_not_match:
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Password failed'),
              ),
            );
            break;
          case RegisterUserState.user_exists:
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Please user exist'),
              ),
            );
            break;
            break;
          case RegisterUserState.weak_password:
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Please use a stronger password'),
              ),
            );
            break;
          case RegisterUserState.failed:
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Check connection'),
              ),
            );
            break;
          case RegisterUserState.loginsuccess:
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Login'),
              ),
            );
            break;
          case RegisterUserState.signOut:
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Logout'),
              ),
            );
            break;
          case RegisterUserState.initial:
            CircularProgressIndicator();
            break;
        }
      }, builder: (context, state) {
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFileComponent(
                textEditingController: emailEditingController,
                hint: StringConstants.email,
              ),
              const SizedBox(
                height: 20,
              ),
              TextFileComponent(
                textEditingController: passwordEditingController,
                hint: StringConstants.password,
              ),
              const SizedBox(
                height: 20,
              ),
              ElevatedButton(
                  onPressed: () {
                    context.read<RegisterUserCubit>().loginUser(
                        email: emailEditingController.text,
                        password: passwordEditingController.text);
                  },
                  child: Text(StringConstants.login)),
              const SizedBox(
                height: 20,
              ),
              ElevatedButton(
                  onPressed: () {
                    context.read<RegisterUserCubit>().registerUser(
                        email: emailEditingController.text,
                        password: passwordEditingController.text);
                  },
                  child: Text(StringConstants.signUp)),
              const SizedBox(
                height: 20,
              ),
              ElevatedButton(
                  onPressed: () {
                    context.read<RegisterUserCubit>().signOut();
                  },
                  child: Text('Logout'))
            ],
          ),
        );
      })),
    );
  }
}
