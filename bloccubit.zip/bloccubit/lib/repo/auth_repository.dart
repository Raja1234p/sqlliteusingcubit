import 'package:bloccubit/listener/auth_registeration_listener.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthRepository {

  void registerUser({
    required String email,
    required String password,
    required AuthRegistrationListener authRegistrationListener
  }) async {
    var authInstance = FirebaseAuth.instance;
    try {
      UserCredential userCredential = await authInstance.createUserWithEmailAndPassword(
          email: email,
          password: password
      );
      authRegistrationListener.success();

    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        print('The password provided is too weak.');
        authRegistrationListener.weakPassword();
      } else if (e.code == 'email-already-in-use') {
        print('The account already exists for that email.');
        authRegistrationListener.userExists();
      }
    } catch (e) {
      print(e);
      authRegistrationListener.failed();
    }
  }

  void loginregisterUser({
    required String email,
    required String password,
    required AuthRegistrationListener authRegistrationListener
  }) async {
    var authInstance = FirebaseAuth.instance;
    try {
      UserCredential userCredential = await authInstance.signInWithEmailAndPassword(
          email: email,
          password: password
      );
      authRegistrationListener.login();

    } on FirebaseAuthException catch (e) {
      if  (e.code == 'user-not-found')  {
        authRegistrationListener.userNotExist();
      } else  if (e.code == 'wrong-password') {
        authRegistrationListener.passwordNotMatch();
      }
    } catch (e) {
      print(e);
      authRegistrationListener.failed();
    }
  }
void signOut({required AuthRegistrationListener authRegistrationListener})async{
       var authInstance = FirebaseAuth.instance;
  await authInstance.signOut();
       authRegistrationListener.signOut();

  }
}