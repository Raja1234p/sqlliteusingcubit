import 'package:bloccubit/listener/auth_registeration_listener.dart';
import 'package:bloccubit/repo/auth_repository.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

enum RegisterUserState {
  success,
  user_exists,
  weak_password,
  failed,
  initial,
  user_not_exist,
  password_not_match,
  loginsuccess,
  signOut
}

class RegisterUserCubit extends Cubit<RegisterUserState> implements AuthRegistrationListener {

  final _authRepository = AuthRepository();
  bool check=false;

  RegisterUserCubit(RegisterUserState initialState) : super(initialState);

  void registerUser({required String email, required String password}) {
    _authRepository.registerUser(email: email, password: password, authRegistrationListener: this);
  }
  void loginUser({required String email, required String password}) {
    _authRepository.loginregisterUser(email: email, password: password, authRegistrationListener: this);
  }
  void logout({required String email, required String password}) {
    _authRepository.signOut( authRegistrationListener: this);
  }

  @override
  void failed() {
    emit(RegisterUserState.initial);
    emit(RegisterUserState.failed);

  }

  @override
  void success() {
    emit(RegisterUserState.success);
  }

  @override
  void userExists() {
    emit(RegisterUserState.initial);
    emit(RegisterUserState.user_exists);
  }

  @override
  void weakPassword() {
    emit(RegisterUserState.initial);
    emit(RegisterUserState.weak_password);
  }
  @override
  void passwordNotMatch() {
    emit(RegisterUserState.initial);
    emit(RegisterUserState.password_not_match);
  }
  @override
  void userNotExist() {
    emit(RegisterUserState.initial);
    emit(RegisterUserState.user_not_exist);
  }
  @override
  void login() {
    emit(RegisterUserState.loginsuccess);

  }
  @override
  void signOut() {
    emit(RegisterUserState.signOut);

  }
}