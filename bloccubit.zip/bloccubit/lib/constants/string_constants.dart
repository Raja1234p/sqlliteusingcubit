class StringConstants{
  static const String title='Login';
  static const String email='Email';
  static const String password='Password';
  static const String login='Login';
  static const String signUp='Sign Up';


}