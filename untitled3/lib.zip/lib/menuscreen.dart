import 'dart:async';

import 'package:easy_dialog/easy_dialog.dart';
import 'package:flutter/material.dart';
import 'package:untitled3/color.dart';
import 'package:responsive_framework/responsive_framework.dart';
import 'package:untitled3/networkclass.dart';

import 'carteilmodel.dart';
import 'dialogbox.dart';
import 'getdeliveryzone.dart';
import 'itemname.dart';

class Responsives extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      builder: (context, widget) => ResponsiveWrapper.builder(
          BouncingScrollWrapper.builder(context, widget),
          maxWidth: 1200,
          minWidth: 450,
          defaultScale: true,
          breakpoints: [
            ResponsiveBreakpoint.resize(450, name: 'MOBILE'),
            ResponsiveBreakpoint.resize(800, name: 'TABLET'),
            ResponsiveBreakpoint.autoScale(1000, name: TABLET),
            ResponsiveBreakpoint.resize(1200, name: DESKTOP),
            ResponsiveBreakpoint.autoScale(2460, name: "4K"),
            ResponsiveBreakpoint.autoScale(600)
          ],
          background: Container(
            color: Colors.white,
          )),
      theme: Theme.of(context).copyWith(platform: TargetPlatform.android),
      debugShowCheckedModeBanner: false,
      home: Menu(),
    );
  }
}

//Menu class
class Menu extends StatefulWidget with PreferredSizeWidget {
  @override
  _MenuState createState() => _MenuState();

  @override
  // TODO: implement preferredSize
  Size get preferredSize => throw UnimplementedError();
}

class _MenuState extends State<Menu> with SingleTickerProviderStateMixin {
  Future<ItemModel> itemmodel;
  Future<Deliveryzone> deliveryzonemodel;
  LocalArea local;
 // LocalArea areaname;
  List<DeliveryZones> deliveryZoneList;

  DeliveryZones deliveryZones;



  List<LocalArea> areaname = <LocalArea>[
    LocalArea('Johar'),
    LocalArea('defence'),
    LocalArea('sadar')
  ];

  TabController _controller;
  int _selectedIndex = 0;

  List<Widget> list = [
    Tab(
      text: 'ROLLS',
    ),
    Tab(text: 'PASTA'),
    Tab(text: 'BURGERS'),
    Tab(text: 'PIZZA'),
    Tab(text: 'CHINESE'),
    Tab(text: 'FASTFOOD'),
  ];

  int _controllerLength;

  List<Products> my_product;
  CUSTOMDIALOGUE customdialogue ;
  @override
  void initState() {
    super.initState();



    itemmodel = Network().getitemmodel();

    deliveryzonemodel = Network().getZones();
    itemmodel.then((data) => {
          // for(int i=0;i<data.itemDetails.length; i++){
          //   for(int y=0;i<data.itemDetails[i].products.length;y++){
          //     print(data.itemDetails[i].products[y].itemTitle)
          //   }
          // }

          data.itemDetails.forEach((element) {
            // element.products.forEach((product) {
            //   print(product.itemTitle);
            // });

            my_product = element.products;
          }),


          _controller = TabController(length: data.itemDetails.length, vsync: this),
          _controller.addListener(() {
            setState(() {
              _selectedIndex = _controller.index;
            });
          }),
        });


    deliveryzonemodel.then((data) => {


      deliveryZoneList = data.deliveryZones,
    WidgetsBinding.instance.addPostFrameCallback((_) => _dialog()),
    });


  }

  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   // Create TabController for getting the index of current tab
  //
  //   _controller = TabController(length: list.length, vsync: this);
  //
  //   _controller.addListener(() {
  //     setState(() {
  //       _selectedIndex = _controller.index;
  //     });
  //     print("Selected Index: " + _controller.index.toString());
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 120,

        bottom: PreferredSize(
          preferredSize: Size.fromHeight(50.0),
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: 60,
            color: Colors.white,
            child: FutureBuilder<ItemModel>(
              future: itemmodel,
              builder: (build, AsyncSnapshot<ItemModel> snapshot) {
                if (snapshot.hasData) {
                  List<Widget> tabs = new List<Widget>();

                  for (int i = 0; i < snapshot.data.itemDetails.length; i++) {



                    tabs.add(Tab(
                      child: Text(
                        snapshot.data.itemDetails[i].categoryName,
                      ),
                    ));
                    print("category:$i");


                    // print(snapshot.data.itemDetails[i].categoryName);
                    // print(snapshot.data.itemDetails.first.products[i].itemTitle);
                  }
                  print("category:");


                  return TabBar(

                      labelColor: Colors.black45,
                      indicator: BoxDecoration(color: Colors.lightBlue.shade50),
                      onTap: (index) {
                        _controller.addListener(() {
                          setState(() {
                            _selectedIndex = _controller.index;
                          });
                          print("Selected Index: " +
                              _controller.index.toString());
                        });
                      },
                      controller: _controller,
                      isScrollable: true,
                      tabs: tabs);
                }
                if (snapshot.hasError) print(snapshot.error.toString());
                return Scaffold(
                  body: Center(
                      child: Text(snapshot.hasError
                          ? snapshot.error.toString()
                          : "Loading...")),
                );
              },
            ),
          ),
        ),
        title: Padding(
          padding: const EdgeInsets.only( top: 20),
          child: Image.asset(
            'images/Logo.png',
            fit: BoxFit.cover,
            height: 55,
          ),
        ),
        centerTitle: true,
        backgroundColor: appbarcolor,
      ),

      body: FutureBuilder<ItemModel>(
        future: itemmodel,
        builder: (BuildContext context, AsyncSnapshot<ItemModel> snapshot) {
          if(snapshot.hasData) {
            return TabBarView(
              controller: _controller,
              children: List<Widget>.generate(snapshot.data.itemDetails.length,
                      (int index) {
                    return Itemsnames.product(
                        snapshot.data.itemDetails[index].products);
                  }),
            );
          }else{
            return CircularProgressIndicator();
          }
        },
      ),
    );
  }

  // List<Itemsnames> getProducts() {
  //   List<Itemsnames> my_list;
  //   FutureBuilder<ItemModel>(
  //       future: itemmodel,
  //       builder: (build, AsyncSnapshot<ItemModel> snapshot) {
  //         if (snapshot.hasData) {
  //           my_list.add(Itemsnames());
  //           my_list.add(Itemsnames());
  //           my_list.add(Itemsnames());
  //           my_list.add(Itemsnames());
  //           my_list.add(Itemsnames());
  //           my_list.add(Itemsnames());
  //         }
  //
  //         return CircularProgressIndicator();
  //       });
  //   return my_list;
  // }

  Future<void> _dialog() async {


    GlobalKey<FormState> _key = GlobalKey<FormState>();
    await showDialog<void>(
        barrierColor: Colors.transparent.withOpacity(0.9),
        context: context,
        builder: (BuildContext context) {
          return Form(
            key: _key,
            child: AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              title: Column(
                children: [
                  Row(
                    // crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Select Delivery area'),
                      IconButton(
                          icon: Icon(Icons.close),
                          onPressed: () {
                            Navigator.of(context).pop();
                          }),
                    ],
                  ),
                ],
              ),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                return SingleChildScrollView(
                  child: ListBody(
                    children: [
                      Text('Delivery Area: Minimum order amount'),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(width: 2)
                          ),
                          child: DropdownButtonFormField<DeliveryZones>(
                            decoration: InputDecoration.collapsed(hintText: ""),
                            validator: (value) =>
                                value == null ? 'field required' : null,
                            hint: Text('Select Area'),
                            value: deliveryZones,
                            isExpanded: true,
                            onChanged: (DeliveryZones value) {
                              setState(() {
                                deliveryZones = value;
                              });
                            },
                            items: deliveryZoneList.map((DeliveryZones raja) {
                              return DropdownMenuItem<DeliveryZones>(
                                value: raja,
                                child: Row(
                                  children: <Widget>[
                                    Text(
                                      raja.areaName,
                                      style: TextStyle(color: Colors.red),
                                    )
                                  ],
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      )
                    ],
                  ),
                );
              }),
              actions: [
                RaisedButton(
                    color: Colors.blue,
                    child: Text(
                      'Select',
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: () {
                      if (_key.currentState.validate()) {
                        Navigator.of(context).pop();
                      }
                    })
              ],
            ),
          );
        });
  }

  void _customRateEasyDialog() {
    EasyDialog(
        cornerRadius: 15.0,
        fogOpacity: 0.1,
        width: MediaQuery.of(context).size.width,
        height: 180,
        contentPadding: EdgeInsets.only(top: 12.0),
        // Needed for the button design
        contentList: [
          Expanded(
            flex: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Padding(padding: EdgeInsets.only(left: 30.0)),
                Text(
                  "Rate",
                  style: TextStyle(fontWeight: FontWeight.bold),
                  textScaleFactor: 1.3,
                ),
                Padding(padding: EdgeInsets.only(left: 10.0)),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(5, (index) {
                    return Icon(
                      index < 3 ? Icons.star : Icons.star_border,
                      size: 30.0,
                      color: Colors.orange,
                    );
                  }),
                )
              ],
            ),
          ),
          Expanded(
              flex: 3,
              child: Padding(
                padding: EdgeInsets.all(10.0),
                child: TextFormField(
                  maxLines: 5,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Add review",
                  ),
                ),
              )),
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
                color: Colors.greenAccent,
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(10.0),
                    bottomRight: Radius.circular(10.0))),
            child: FlatButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                "Rate",
                textScaleFactor: 1.3,
              ),
            ),
          ),
        ]).show(context);
  }
}

class LocalArea {
  final String areaname;

  const LocalArea(this.areaname);
}
