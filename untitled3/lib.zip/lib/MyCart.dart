class MyCart {
  String name;
  int Price;
  int Quantity;

  MyCart(this.name, this.Price, this.Quantity);



}