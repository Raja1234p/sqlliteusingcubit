class ItemModel {
  List<ItemDetails> itemDetails;

  ItemModel({this.itemDetails});

  ItemModel.fromJson(Map<String, dynamic> json) {
    if (json['item_details'] != null) {
      itemDetails = new List<ItemDetails>();
      json['item_details'].forEach((v) {
        itemDetails.add(new ItemDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.itemDetails != null) {
      data['item_details'] = this.itemDetails.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ItemDetails {
  int categoryId;
  String shopId;
  String categoryName;
  String isActive;
  String sort;
  String createdAt;
  String updatedAt;
  List<Products> products;

  ItemDetails(
      {this.categoryId,
        this.shopId,
        this.categoryName,
        this.isActive,
        this.sort,
        this.createdAt,
        this.updatedAt,
        this.products});

  ItemDetails.fromJson(Map<String, dynamic> json) {
    categoryId = json['category_id'];
    shopId = json['shop_id'];
    categoryName = json['category_name'];
    isActive = json['is_active'];
    sort = json['sort'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    if (json['products'] != null) {
      products = new List<Products>();
      json['products'].forEach((v) {
        products.add(new Products.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['category_id'] = this.categoryId;
    data['shop_id'] = this.shopId;
    data['category_name'] = this.categoryName;
    data['is_active'] = this.isActive;
    data['sort'] = this.sort;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    if (this.products != null) {
      data['products'] = this.products.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Products {
  int itemId;
  String shopId;
  String categoryId;
  String itemTitle;
  String itemImagePath;
  String itemImageName;
  String itemDescription;
  String price;
  String oldPrice;
  String isActive;
  List<MetaData> metaData;
  String createdAt;
  String updatedAt;

  bool isSelected = false;


  Products(
      {this.itemId,
        this.shopId,
        this.categoryId,
        this.itemTitle,
        this.itemImagePath,
        this.itemImageName,
        this.itemDescription,
        this.price,
        this.oldPrice,
        this.isActive,
        this.metaData,
        this.createdAt,
        this.updatedAt});

  Products.fromJson(Map<String, dynamic> json) {
    itemId = json['item_id'];
    shopId = json['shop_id'];
    categoryId = json['category_id'];
    itemTitle = json['item_title'];
    itemImagePath = json['item_image_path'];
    itemImageName = json['item_image_name'];
    itemDescription = json['item_description'];
    price = json['price'];
    oldPrice = json['old_price'];
    isActive = json['is_active'];
    if (json['meta_data'] != null) {
      metaData = new List<MetaData>();
      json['meta_data'].forEach((v) {
        metaData.add(new MetaData.fromJson(v));
      });
    }
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['item_id'] = this.itemId;
    data['shop_id'] = this.shopId;
    data['category_id'] = this.categoryId;
    data['item_title'] = this.itemTitle;
    data['item_image_path'] = this.itemImagePath;
    data['item_image_name'] = this.itemImageName;
    data['item_description'] = this.itemDescription;
    data['price'] = this.price;
    data['old_price'] = this.oldPrice;
    data['is_active'] = this.isActive;
    if (this.metaData != null) {
      data['meta_data'] = this.metaData.map((v) => v.toJson()).toList();
    }
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}

class MetaData {
  String categoryName;
  List<String> products;

  MetaData({this.categoryName, this.products});

  MetaData.fromJson(Map<String, dynamic> json) {
    categoryName = json['category_name'];
    products = json['products'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['category_name'] = this.categoryName;
    data['products'] = this.products;
    return data;
  }
}