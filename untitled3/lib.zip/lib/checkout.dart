import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled3/Getcartitems.dart';
import 'package:untitled3/networkclass.dart';

import 'color.dart';
class CheckOutFrom extends StatefulWidget {

  AddOrders addOrders;


  CheckOutFrom();


  CheckOutFrom.name(this.addOrders);

  @override
  _CheckOutFromState createState() => _CheckOutFromState.name(addOrders);
}

class _CheckOutFromState extends State<CheckOutFrom> {


  AddOrders addOrders;


  _CheckOutFromState();


  _CheckOutFromState.name(this.addOrders);

  // final mycontroller = TextEditingController();

  TextEditingController firstNameController = TextEditingController();

  LocalArea local;

  List<LocalArea> areaname = <LocalArea>[
    LocalArea('Johar'),
    LocalArea('defence'),
    LocalArea('sadar')
  ];
  final GlobalKey<FormState>_key = GlobalKey<FormState>();
  @override



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: Padding(
        padding: const EdgeInsets.only(bottom: 12.0, top: 7),
        child: Image.asset(
          'images/Logo.png',
          fit: BoxFit.cover,
          height: 55,
        ),
      ),
        centerTitle: true,
        backgroundColor: appbarcolor,),
      body: Form(
        child: SingleChildScrollView(

            key: _key,
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top:35.0,left: 12,bottom: 23),
              child: Text('Checkout From',style: TextStyle(fontSize: 25),),
            ),


            Padding(
              padding: const EdgeInsets.only(left:14.0,bottom: 10),
              child: RichText(
                text: TextSpan(children: [
                  TextSpan(
                      text: 'First Name', style: TextStyle(color: Colors.black,fontSize: 20)),
                  WidgetSpan(
                    child: Transform.translate(
                      offset: const Offset(1, 1),
                      child: Text(
                        '*',
                        //superscript is usually smaller in size
                        textScaleFactor: 0.7,
                        style: TextStyle(color: Colors.red,fontSize: 25),
                      ),
                    ),
                  )
                ]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:13.0,bottom: 8,top: 8,right: 6),
              child: TextFormField(
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Please enter your name';
                  }
                  return null;
                },
                controller: firstNameController,
                decoration: InputDecoration(
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: Colors.black12)),
                    hintText: 'Please Enter First Name',
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.black12)
                    )
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:14.0,bottom: 10),
              child: RichText(
                text: TextSpan(children: [
                  TextSpan(
                      text: 'Last Name', style: TextStyle(color: Colors.black,fontSize: 20)),
                  WidgetSpan(
                    child: Transform.translate(
                      offset: const Offset(1, 1),
                      child: Text(
                        '*',
                        //superscript is usually smaller in size
                        textScaleFactor: 0.7,
                        style: TextStyle(color: Colors.red,fontSize: 25),
                      ),
                    ),
                  )
                ]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:13.0,bottom: 8,top: 8,right: 6),
              child: TextFormField(
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Please enter your last name';
                  }
                  return null;
                },
                // controller: mycontroller,
                decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.black12)),
                    hintText: 'Please Enter Last Name',
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.black12)
                    )
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:14.0,bottom: 10),
              child: RichText(
                text: TextSpan(children: [
                  TextSpan(
                      text: 'Email', style: TextStyle(color: Colors.black,fontSize: 20)),
                  WidgetSpan(
                    child: Transform.translate(
                      offset: const Offset(1, 1),
                      child: Text(
                        '*',
                        //superscript is usually smaller in size
                        textScaleFactor: 0.7,
                        style: TextStyle(color: Colors.red,fontSize: 25),
                      ),
                    ),
                  )
                ]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:13.0,bottom: 8,top: 8,right: 6),
              child: TextFormField(
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Please enter your email';
                  }
                  return null;
                },
                // controller: mycontroller,
                decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.black12)),
                    hintText: 'Please Enter Email',
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.black12)
                    )
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:14.0,bottom: 10),
              child: RichText(
                text: TextSpan(children: [
                  TextSpan(
                      text: 'Mobile Number', style: TextStyle(color: Colors.black,fontSize: 20)),
                  WidgetSpan(
                    child: Transform.translate(
                      offset: const Offset(1, 1),
                      child: Text(
                        '*',
                        //superscript is usually smaller in size
                        textScaleFactor: 0.7,
                        style: TextStyle(color: Colors.red,fontSize: 25),
                      ),
                    ),
                  )
                ]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:13.0,bottom: 8,top: 8,right: 6),
              child: TextFormField(
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Please enter your number';
                  }
                  return null;
                },
                // controller: mycontroller,
                decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.black12)),
                    hintText: '03xxxxxxxx',
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.black12)
                    )
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:14.0,bottom: 10),
              child: RichText(
                text: TextSpan(children: [
                  TextSpan(
                      text: 'Area', style: TextStyle(color: Colors.black,fontSize: 20)),
                  WidgetSpan(
                    child: Transform.translate(
                      offset: const Offset(1, 1),
                      child: Text(
                        '*',
                        //superscript is usually smaller in size
                        textScaleFactor: 0.7,
                        style: TextStyle(color: Colors.red,fontSize: 25),
                      ),
                    ),
                  )
                ]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:13.0,bottom: 8,top: 8,right: 6),
              child: Container(

                height: 60,
                decoration: BoxDecoration(
                    color: Colors.black12,
                  border: Border.all(color: Colors.black12),
                  borderRadius: BorderRadius.circular(10)
                ),
                child: Center(
                  child: DropdownButtonFormField<LocalArea>(

                    decoration: InputDecoration.collapsed(hintText: ""),

                    validator: (value) => value == null ? 'field required' : null,

                    hint: Text('Select Area'),

                    value: local,
                    isExpanded: true,
                    onChanged: (LocalArea value) {
                      setState(() {
                        local = value;
                      });
                    },
                    items: areaname.map((LocalArea raja) {
                      return DropdownMenuItem<LocalArea>(
                        value: raja,
                        child: Row(
                          children: <Widget>[
                            SizedBox(width: 10,),
                            Text(
                              raja.areaname,
                              style: TextStyle(color: Colors.black),
                            )
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:14.0,bottom: 10),
              child: RichText(
                text: TextSpan(children: [
                  TextSpan(
                      text: 'Address', style: TextStyle(color: Colors.black,fontSize: 20)),
                  WidgetSpan(
                    child: Transform.translate(
                      offset: const Offset(1, 1),
                      child: Text(
                        '*',
                        //superscript is usually smaller in size
                        textScaleFactor: 0.7,
                        style: TextStyle(color: Colors.red,fontSize: 25),
                      ),
                    ),
                  )
                ]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:13.0,bottom: 8,top: 8,right: 6),
              child: TextFormField(
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Please enter your address';
                  }
                  return null;
                },
                // controller: mycontroller,
                decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.black12)),
                    hintText: 'Please Enter Address',
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: Colors.black12)
                    )
                ),
              ),
            ),
            Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  width: 130,
                  child: RaisedButton(onPressed: () async{

                    addOrders.firstName = firstNameController.text;
                    addOrders.lastName = firstNameController.text;
                    addOrders.email = "mwaqasiu@gmail.com";
                    addOrders.contactNumber = "030702101516";
                         // print('posting data');
                          print(firstNameController.text);
                         await   Network.postOrderData(addOrders).then((value) => print('Posting data done'));


                    // if (_key.currentState.validate()){
                    //   //scaf(context);
                    //   print('done');
                    //   // mycontroller.clear();
                    //
                    // }else{print('hhh');}
                  },color: Colors.blue,
                  child: Text('submit'.toUpperCase(),style: TextStyle(color: Colors.white),),),
                ),
              ),
            )

          ],
        )),
      ),
    );
  }

  Widget scaf(BuildContext context){

    return Scaffold(
      body: SnackBar(content: Text('done')),
    );
  }


}
class LocalArea {
  final String areaname;

  const LocalArea(this.areaname);
}








