import 'dart:ui';

import 'package:flutter/cupertino.dart';

class Menumodel{

bool press;
   Image image;

   int q ;

  Menumodel( this.q,this.image,this.press);

  static List<Menumodel> getimae()=>[
        Menumodel(11,Image.asset('images/roll.png',fit: BoxFit.cover,), true),
   Menumodel(22,Image.asset('images/pizza.jpg',fit: BoxFit.cover,),true),
    Menumodel(33,Image.asset('images/pasta.jpg',fit: BoxFit.cover,),true),

    Menumodel(44,Image.asset('images/roll.png',fit: BoxFit.cover,),true),
    Menumodel(55,Image.asset('images/roll.png',fit: BoxFit.cover,),true),
    Menumodel(66,Image.asset('images/roll.png',fit: BoxFit.cover,),true),




  ];



}