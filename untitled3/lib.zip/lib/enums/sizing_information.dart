import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import 'device_screen_type.dart';

class SizingInformation {
  final Orientation orientation;
  final DeviceScreenType deviceType;
  final Size screenSize;
  final Size localWidgetSize;

  SizingInformation({
    this.orientation,
    this.deviceType,
    this.screenSize,
    this.localWidgetSize,
  });

  @override
  String toString() {
    return 'Orientation:$orientation DeviceType:$deviceType ScreenSize:$screenSize LocalWidgetSize:$localWidgetSize';
  }
}

class BaseWidget extends StatelessWidget {
  final Widget Function(
      BuildContext context, SizingInformation sizingInformation) builder;

  const BaseWidget({Key key, this.builder}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var medaiquery = MediaQuery.of(context);


    return LayoutBuilder(builder: (context, boxConstraints) {
      var sizingInformation = SizingInformation(
        orientation: medaiquery.orientation,
        deviceType: getdevicetype(medaiquery),
        screenSize: medaiquery.size,
        localWidgetSize: Size(boxConstraints.maxWidth, boxConstraints.maxHeight)
      );
      return builder(context, sizingInformation);
    });
  }
}

class HomeView extends StatelessWidget {
  const HomeView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BaseWidget(builder: (context, sizingInformation) {
      return Scaffold(
          body: Center(
        child: Text(sizingInformation.toString()),
      ));
    });
  }
}

DeviceScreenType getdevicetype(MediaQueryData mediaQueryData) {
  var orientation = mediaQueryData.orientation;

  double devicewidth = 0;

  if (orientation == Orientation.landscape) {
    devicewidth = mediaQueryData.size.height;
  } else {
    devicewidth = mediaQueryData.size.width;
  }
  if (devicewidth > 950) {
    return DeviceScreenType.Desktop;
  }
  if (devicewidth > 600) {
    return DeviceScreenType.Tablet;
  }

  return DeviceScreenType.Mobile;
}
