import 'package:flutter/material.dart';




import 'Splash.dart';
import 'checkout.dart';


void main(){

  runApp(MaterialApp(home: Responsive(),));
}



class RadioWidgetDemo extends StatefulWidget {
  RadioWidgetDemo() : super();

  final String title = "Radio Widget Demo";

  @override
  RadioWidgetDemoState createState() => RadioWidgetDemoState();
}

class RadioWidgetDemoState extends State<RadioWidgetDemo> {
  //
  List<User> users;
  User selectedUser;


  @override
  void initState() {
    super.initState();

    users = User.getUsers();
  }



  setSelectedUser(User user) {
    setState(() {
      selectedUser = user;
    });
  }

  List<Widget> createRadioListUsers() {
    List<Widget> widgets = [];
    for (User user in users) {
      widgets.add(
        RadioListTile(
          value: user,
          groupValue: selectedUser,
          title: Text(user.firstName),

          onChanged: (currentUser) {
            print("Current User ${currentUser.firstName}");
            setSelectedUser(currentUser);
          },
          selected: selectedUser == user,
          activeColor: Colors.blue,
        ),
      );
    }
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    return  Column(
        children: createRadioListUsers(),
      );

  }
}




class User {

  String firstName;


  User(this.firstName,);

  static List<User> getUsers() {
    return <User>[
      User( "Pizza", ),
      User( "burger", ),
      User( "cold drink",),

    ];
  }
}









class Radiolist2 extends StatefulWidget {
  Radiolist2() : super();

  final String title = "Radio Widget Demo";

  @override
  Radiolist2State createState() => Radiolist2State();
}

class Radiolist2State extends State<Radiolist2> {
  //
  List<User> users;
  User selectedUser;


  @override
  void initState() {
    super.initState();

    users = User.getUsers();
  }



  setSelectedUser(User user) {
    setState(() {
      selectedUser = user;
    });
  }

  List<Widget> myuser() {
    List<Widget> widgets = [];
    for (User user in users) {
      widgets.add(
        RadioListTile(

          value: user,
          groupValue: selectedUser,
          title: Text(user.firstName),

          onChanged: (currentUser) {
            print("Current User ${currentUser.firstName}");
            setSelectedUser(currentUser);
          },
          selected: selectedUser == user,
          activeColor: Colors.blue,
        ),
      );
    }
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    return  Column(
      children: myuser(),
    );

  }
}




class Radios {

  String firstName;


  Radios(this.firstName,);

  static List<Radios> getUsers() {
    return <Radios>[
      Radios( "Club Sandwich", ),
      Radios( "burger", ),
      Radios( "Zinegr",),

    ];
  }
}
