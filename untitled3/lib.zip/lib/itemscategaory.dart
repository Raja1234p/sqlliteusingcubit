

import 'package:flutter/material.dart';
import 'package:responsive_framework/responsive_framework.dart';


class Response extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      builder: (context, widget) => ResponsiveWrapper.builder(
          BouncingScrollWrapper.builder(context, widget),
      maxWidth: 1200,
        minWidth: 450,
        defaultScale: true,
        breakpoints: [

          ResponsiveBreakpoint.resize(450, name: 'MOBILE'),
          ResponsiveBreakpoint.resize(800, name: 'TABLET'),
          ResponsiveBreakpoint.autoScale(1000, name: TABLET),
          ResponsiveBreakpoint.resize(1200, name: DESKTOP),
          ResponsiveBreakpoint.autoScale(2460, name: "4K"),
          ResponsiveBreakpoint.autoScale(600)
        ],background: Container(
        color: Colors.white,
      ),
      ),
      debugShowCheckedModeBanner: false,
      theme: Theme.of(context).copyWith(platform: TargetPlatform.android),
      // home: Allitems(),
    );
  }
}




