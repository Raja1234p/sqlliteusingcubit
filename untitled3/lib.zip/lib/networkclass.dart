import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'package:untitled3/Getcartitems.dart';
import 'package:untitled3/getdeliveryzone.dart';

import 'carteilmodel.dart';

class Network {
  // ignore: non_constant_identifier_names
  static var base_url = "http://cartelapi.textiledigitizing.com/api/";

  Future<ItemModel> getitemmodel() async {
    var get_item_url = Network.base_url + "getproducts";

    final response = await get(Uri.encodeFull(get_item_url));
    print(Uri.encodeFull(get_item_url));
    if (response.statusCode == 200) {
      // print("data of api ${response.body}");
      return ItemModel.fromJson(json.decode(response.body));
    } else {
      throw Exception('nullll');
    }
  }

  Future<Deliveryzone> getZones() async {
    var getZoneurl = Network.base_url + "getdeliveryzones";

    final response = await get(Uri.encodeFull(getZoneurl));
    print(Uri.encodeFull(getZoneurl));
    if (response.statusCode == 200) {
      // print("data of api ${response.body}");
      return Deliveryzone.fromJson(json.decode(response.body));
    } else {
      throw Exception('nullll');
    }
  }

  // static void postMyData() async {
  //   List<OrderDetails> orderDetails = List<OrderDetails>();
  //
  //   orderDetails.add(OrderDetails(
  //       itemId: 1,
  //       itemPrice: 100,
  //       itemQuantity: 1,
  //       itemInstruction: "kjasdkjasd"));
  //
  //   MetaDataOrder metaDataOrder = MetaDataOrder(orderDetails: orderDetails);
  //
  //   AddOrders addOrders = AddOrders(
  //     address: "asdasda",
  //     contactNumber: "03070210516",
  //     couponDiscount: 20,
  //     couponId: 1,
  //     deliveryCharges: 600,
  //     deliveryZoneId: 1,
  //     email: "mwaqasiu@gmail.com",
  //     firstName: "Raja",
  //     lastName: "Poran",
  //     grandTotal: 800,
  //     metaData: metaDataOrder,
  //     orderInstruction: "hjsagdjaghsdjhgas",
  //     orderStatus: "pending",
  //     shopId: 1
  //   );
  //
  //   // Map<dynamic, dynamic> body = {
  //   //   "delivery_zone_id": '1',
  //   //   "coupon_id": "1",
  //   //   "first_name": "Asad",
  //   //   "last_name": "Amjad",
  //   //   "email": "asadamjad781@gmail.com",
  //   //   "address": "Mehmoodabad",
  //   //   "contact_number": "0336283392",
  //   //   "order_instruction": "with meal and ketchup and spicy",
  //   //   "grand_total": "800",
  //   //   "coupon_discount": "20",
  //   //   "delivery_charges": "600",
  //   //   "order_status": "pending",
  //   //   "meta_data": metaDataOrder.,
  //   //   "shop_id": "1"
  //   // };
  //
  //   var postDataUrl = Network.base_url + "addorders";
  //
  //   // FormData formData = FormData();
  //   // formData.append("first_name", "Hello");
  //
  //
  //
  //   final response = await post(postDataUrl, body: formData);
  //
  //   if (response.statusCode == 200) {
  //     // print("data of api ${response.body}");
  //     print("success");
  //   } else {
  //     print("error :(:(:(:(:(");
  //     // throw Exception('nullll');
  //   }
  // }









  static Future<AddOrders> postOrderData(AddOrders postOrder) async {


      // List<OrderDetails> orderDetails = List<OrderDetails>();
      //
      // orderDetails.add(OrderDetails(
      //     itemId: 1,
      //     itemPrice: 100,
      //     itemQuantity: 1,
      //     itemInstruction: "kjasdkjasd"));
      //
      // MetaDataOrder metaDataOrder = MetaDataOrder(orderDetails: orderDetails);
      //
      // AddOrders addOrders = AddOrders(
      //   address: "asdasda",
      //   contactNumber: "03070210516",
      //   couponDiscount: 20,
      //   couponId: 1,
      //   deliveryCharges: 600,
      //   deliveryZoneId: 1,
      //   email: "mwaqasiu@gmail.com",
      //   firstName: "Raja",
      //   lastName: "Poran",
      //   grandTotal: 800,
      //   metaData: metaDataOrder,
      //   orderInstruction: "hjsagdjaghsdjhgas",
      //   orderStatus: "pending",
      //   shopId: 1
      // );


    final http.Response response = await http.post(
      "http://cartelapi.textiledigitizing.com/api/addorders",
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<dynamic, dynamic>{
        'first_name': postOrder.firstName,
        'last_name' : postOrder.lastName,
        'email' : postOrder.email,
        'contact_number' : postOrder.contactNumber,
        'address' : postOrder.address,
        'grand_total' : postOrder.grandTotal,
        'order_status' : postOrder.orderStatus,
        'coupon_discount' : postOrder.couponDiscount,
        'coupon_id' : postOrder.couponId,
        'delivery_zone_id' : postOrder.deliveryZoneId,
        'grand_total' : postOrder.grandTotal,
        'delivery_charges' : postOrder.deliveryCharges,
        'order_status' : postOrder.orderStatus,
        'order_instruction' : postOrder.orderInstruction,
        'meta_data' : jsonEncode(postOrder.metaData.toJson()),
        'shop_id' : postOrder.shopId

      }),
    );
    if (response.statusCode == 200) {
      // If the server did return a 201 CREATED response,
      // then parse the JSON.

      //print();
      print(response.body);
      //return jsonDecode(response.body);
    } else {
      // If the server did not return a 201 CREATED response,
      // then throw an exception.
      throw Exception('Failed to load album');
    }
  }

}
