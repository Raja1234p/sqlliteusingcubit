import 'package:untitled3/Getcartitems.dart';
import 'package:untitled3/MyCart.dart';


class Test {

static int myPrice =0;
 static List<OrderDetails> myCart = List<OrderDetails>();


 static void setMyCart(OrderDetails myCartData){
    myCart.add(myCartData);
  }

 static void remvoveMyCart(OrderDetails myCartData){
   myCart.removeWhere((item) =>  item.itemPrice == myCartData.itemPrice );

 }
 static  remvovesMyCart(MyCart myCartData){
   myCart.clear();

 }
  static List<OrderDetails> getCart(){
    return myCart;
  }


}