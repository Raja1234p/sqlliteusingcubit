class AddOrders {
  int _deliveryZoneId;
  int _couponId;
  String _firstName;
  String _lastName;
  String _email;
  String _address;
  String _contactNumber;
  String _orderInstruction;
  int _grandTotal;
  int _couponDiscount;
  int _deliveryCharges;
  String _orderStatus;
  int _shopId;
  MetaDataOrder _metaData;

  AddOrders(
      {int deliveryZoneId,
        int couponId,
        String firstName,
        String lastName,
        String email,
        String address,
        String contactNumber,
        String orderInstruction,
        int grandTotal,
        int couponDiscount,
        int deliveryCharges,
        String orderStatus,
        int shopId,
        MetaDataOrder metaData}) {
    this._deliveryZoneId = deliveryZoneId;
    this._couponId = couponId;
    this._firstName = firstName;
    this._lastName = lastName;
    this._email = email;
    this._address = address;
    this._contactNumber = contactNumber;
    this._orderInstruction = orderInstruction;
    this._grandTotal = grandTotal;
    this._couponDiscount = couponDiscount;
    this._deliveryCharges = deliveryCharges;
    this._orderStatus = orderStatus;
    this._shopId = shopId;
    this._metaData = metaData;
  }

  int get deliveryZoneId => _deliveryZoneId;
  set deliveryZoneId(int deliveryZoneId) => _deliveryZoneId = deliveryZoneId;
  int get couponId => _couponId;
  set couponId(int couponId) => _couponId = couponId;
  String get firstName => _firstName;
  set firstName(String firstName) => _firstName = firstName;
  String get lastName => _lastName;
  set lastName(String lastName) => _lastName = lastName;
  String get email => _email;
  set email(String email) => _email = email;
  String get address => _address;
  set address(String address) => _address = address;
  String get contactNumber => _contactNumber;
  set contactNumber(String contactNumber) => _contactNumber = contactNumber;
  String get orderInstruction => _orderInstruction;
  set orderInstruction(String orderInstruction) =>
      _orderInstruction = orderInstruction;
  int get grandTotal => _grandTotal;
  set grandTotal(int grandTotal) => _grandTotal = grandTotal;
  int get couponDiscount => _couponDiscount;
  set couponDiscount(int couponDiscount) => _couponDiscount = couponDiscount;
  int get deliveryCharges => _deliveryCharges;
  set deliveryCharges(int deliveryCharges) =>
      _deliveryCharges = deliveryCharges;
  String get orderStatus => _orderStatus;
  set orderStatus(String orderStatus) => _orderStatus = orderStatus;
  int get shopId => _shopId;
  set shopId(int shopId) => _shopId = shopId;
  MetaDataOrder get metaData => _metaData;
  set metaData(MetaDataOrder metaData) => _metaData = metaData;

  AddOrders.fromJson(Map<String, dynamic> json) {
    _deliveryZoneId = json['delivery_zone_id'];
    _couponId = json['coupon_id'];
    _firstName = json['first_name'];
    _lastName = json['last_name'];
    _email = json['email'];
    _address = json['address'];
    _contactNumber = json['contact_number'];
    _orderInstruction = json['order_instruction'];
    _grandTotal = json['grand_total'];
    _couponDiscount = json['coupon_discount'];
    _deliveryCharges = json['delivery_charges'];
    _orderStatus = json['order_status'];
    _shopId = json['shop_id'];
    _metaData = json['meta_data'] != null
        ? new MetaDataOrder.fromJson(json['meta_data'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['delivery_zone_id'] = this._deliveryZoneId;
    data['coupon_id'] = this._couponId;
    data['first_name'] = this._firstName;
    data['last_name'] = this._lastName;
    data['email'] = this._email;
    data['address'] = this._address;
    data['contact_number'] = this._contactNumber;
    data['order_instruction'] = this._orderInstruction;
    data['grand_total'] = this._grandTotal;
    data['coupon_discount'] = this._couponDiscount;
    data['delivery_charges'] = this._deliveryCharges;
    data['order_status'] = this._orderStatus;
    data['shop_id'] = this._shopId;
    if (this._metaData != null) {
      data['meta_data'] = this._metaData.toJson();
    }
    return data;
  }
}

class MetaDataOrder {
  List<OrderDetails> _orderDetails;

  MetaDataOrder({List<OrderDetails> orderDetails}) {
    this._orderDetails = orderDetails;
  }

  List<OrderDetails> get orderDetails => _orderDetails;
  set orderDetails(List<OrderDetails> orderDetails) =>
      _orderDetails = orderDetails;

  MetaDataOrder.fromJson(Map<String, dynamic> json) {
    if (json['order_details'] != null) {
      _orderDetails = new List<OrderDetails>();
      json['order_details'].forEach((v) {
        _orderDetails.add(new OrderDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this._orderDetails != null) {
      data['order_details'] =
          this._orderDetails.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class OrderDetails {
  int _itemId;
  int _itemPrice;
  int _itemQuantity;
  String _itemInstruction;
  String _itemName;

  OrderDetails({int itemId, int itemPrice, int itemQuantity, String itemInstruction, String itemName}) {
    this._itemId = itemId;
    this._itemPrice = itemPrice;
    this._itemQuantity = itemQuantity;
    this._itemInstruction = itemInstruction;
    this._itemName = itemName;
  }

  int get itemId => _itemId;
  set itemId(int itemId) => _itemId = itemId;
  int get itemPrice => _itemPrice;
  set itemPrice(int itemPrice) => _itemPrice = itemPrice;
  int get itemQuantity => _itemQuantity;
  set itemQuantity(int itemQuantity) => _itemQuantity = itemQuantity;
  String get itemInstruction => _itemInstruction;
  set itemInstruction(String itemInstruction) =>
      _itemInstruction = itemInstruction;

  String get itemName => _itemName;
  set itemName(String itemName) =>
      _itemName = itemName;

  OrderDetails.fromJson(Map<String, dynamic> json) {
    _itemId = json['item_id'];
    _itemPrice = json['item_price'];
    _itemQuantity = json['item_quantity'];
    _itemInstruction = json['item_instruction'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['item_id'] = this._itemId;
    data['item_price'] = this._itemPrice;
    data['item_quantity'] = this._itemQuantity;
    data['item_instruction'] = this._itemInstruction;
    return data;
  }
}