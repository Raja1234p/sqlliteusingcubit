import 'package:flutter/material.dart';
import 'package:untitled3/getdeliveryzone.dart';
class CUSTOMDIALOGUE extends StatefulWidget {


List<DeliveryZones> zonelist;
CUSTOMDIALOGUE();
CUSTOMDIALOGUE.zone(this.zonelist);

  @override
  _CUSTOMDIALOGUEState createState() => _CUSTOMDIALOGUEState.zone(this.zonelist);
}

class _CUSTOMDIALOGUEState extends State<CUSTOMDIALOGUE> {

  List<DeliveryZones> zonelist;
  _CUSTOMDIALOGUEState.zone(this.zonelist);
  DeliveryZones local;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _dialog());
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
  Future<void> _dialog() async {
    GlobalKey<FormState> _key = GlobalKey<FormState>();
    await showDialog<void>(
        barrierColor: Colors.transparent.withOpacity(0.9),
        context: context,
        builder: (BuildContext context) {
          return Form(
            key: _key,
            child: AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              title: Column(
                children: [
                  Row(
                    // crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Select Delivery area'),
                      IconButton(
                          icon: Icon(Icons.close),
                          onPressed: () {
                            Navigator.of(context).pop();
                          }),
                    ],
                  ),
                ],
              ),
              content: StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                    return SingleChildScrollView(
                      child: ListBody(
                        children: [
                          Text('Delivery Area: Minimum order amount'),
                          DropdownButtonFormField<DeliveryZones>(
                            decoration: InputDecoration.collapsed(hintText: ""),
                            validator: (value) =>
                            value == null ? 'field required' : null,
                            hint: Text('Select Area'),
                            value: local,
                            isExpanded: true,
                            onChanged: (DeliveryZones value) {
                              setState(() {
                                local = value;
                              });
                            },
                            items: zonelist.map((DeliveryZones val) {
                              return DropdownMenuItem<DeliveryZones>(
                                value: val,
                                child: Row(
                                  children: <Widget>[
                                    Text(
                                      val.areaName,
                                      style: TextStyle(color: Colors.red),
                                    )
                                  ],
                                ),
                              );
                            }).toList(),
                          )
                        ],
                      ),
                    );
                  }),
              actions: [
                RaisedButton(
                    color: Colors.blue,
                    child: Text(
                      'Select',
                      style: TextStyle(color: Colors.white),
                    ),
                    onPressed: () {
                      if (_key.currentState.validate()) {
                        Navigator.of(context).pop();
                      }
                    })
              ],
            ),
          );
        });
  }
}

