
class Deliveryzone {
  List<DeliveryZones> deliveryZones;

  Deliveryzone({this.deliveryZones});

  Deliveryzone.fromJson(Map<String, dynamic> json) {
    if (json['delivery_zones'] != null) {
      deliveryZones = new List<DeliveryZones>();
      json['delivery_zones'].forEach((v) {
        deliveryZones.add(new DeliveryZones.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.deliveryZones != null) {
      data['delivery_zones'] =
          this.deliveryZones.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class DeliveryZones {
  int deliveryZoneId;
  String shopId;
  String areaName;
  String minimumOrder;
  String deliveryCharges;
  String createdAt;
  String updatedAt;

  DeliveryZones(
      {this.deliveryZoneId,
        this.shopId,
        this.areaName,
        this.minimumOrder,
        this.deliveryCharges,
        this.createdAt,
        this.updatedAt});

  DeliveryZones.fromJson(Map<String, dynamic> json) {
    deliveryZoneId = json['delivery_zone_id'];
    shopId = json['shop_id'];
    areaName = json['area_name'];
    minimumOrder = json['minimum_order'];
    deliveryCharges = json['delivery_charges'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['delivery_zone_id'] = this.deliveryZoneId;
    data['shop_id'] = this.shopId;
    data['area_name'] = this.areaName;
    data['minimum_order'] = this.minimumOrder;
    data['delivery_charges'] = this.deliveryCharges;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}