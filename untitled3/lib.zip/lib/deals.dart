import 'package:flutter/material.dart';

class Deal extends StatefulWidget {
  @override
  _DealState createState() => _DealState();
}

class _DealState extends State<Deal> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: dialog()
    );
  }

  Widget dialog() {
    showGeneralDialog(
        barrierColor: Colors.transparent.withOpacity(0.9),
        context: context,
        pageBuilder: (BuildContext buildcontext, Animation animation,
            Animation secondaryanimation) {

          return Scaffold(
            body: Center(

              child: Padding(
                padding: const EdgeInsets.only(top:20.0,),
                child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    width: MediaQuery.of(context).size.width-20,
                    height: MediaQuery.of(context).size.height,

                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [


                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text('Deal 01',style: TextStyle(fontSize: 15),),
                            ),
                            IconButton(icon: Icon(Icons.clear), onPressed: () => Navigator.of(context).pop())
                          ],),
                        Divider(color: Colors.black87,thickness: 1,)
                      ],
                    )
                ),
              ),
            ),
          );
        });
  }
}
