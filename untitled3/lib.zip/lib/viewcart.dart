import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled3/MyCart.dart';

import 'Getcartitems.dart';
import 'TestList.dart';
import 'carteilmodel.dart';
import 'checkout.dart';

class Cart extends StatefulWidget {
  List<OrderDetails> myCart;

  List<Products> productslist;

  Cart();

  Cart.name(this.myCart, this.productslist);

  @override
  _CartState createState() => _CartState.name(myCart, productslist);
}

class _CartState extends State<Cart> {
  List<OrderDetails> myCart;

  _CartState();

  _CartState.name(this.myCart, this.productslist);

  var _key;

  //final List<Mycart> cart = Mycart.getcart();
  final List<Proceed> proceed = Proceed.getproceed();
  int index;
  List<Products> productslist;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        title: Text('View Cart'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Align(alignment: Alignment.bottomLeft, child: cards(myCart, context)),
          proceeds(proceed.elementAt(0), context)
        ],
      ),
    );
  }

  Widget cards(List<OrderDetails> cart, BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    int _index;

    return Container(
      color: Colors.white,
      width: double.infinity,
      height: MediaQuery.of(context).size.height / 2,
      child: ListView.builder(
        itemCount: cart.length,
        itemBuilder: (BuildContext context, int index) {
          return Container(
            height: 70,
            child: Column(
              children: [
                Divider(
                  height: 2,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          cart[index].itemName,
                          style: TextStyle(fontSize: 20),
                        ),
                      ),
                      Spacer(),
                      Align(
                        alignment: Alignment.topLeft + Alignment(-100, 0),
                        child: IconButton(
                          icon: Icon(Icons.remove),
                          onPressed: () {
                            setState(() {
                              if (myCart[index].itemQuantity > 1) {
                                myCart[index].itemQuantity--;
                                Test.myPrice = 100;
                              } else {
                                Test.remvoveMyCart(OrderDetails(
                                    itemId: productslist[index].itemId,
                                    itemName: productslist[index].itemTitle,
                                    itemQuantity: 1,
                                    itemInstruction:
                                        productslist[index].itemDescription,
                                    itemPrice:
                                        int.parse(productslist[index].price)));

                                productslist[index].isSelected = false;
                                Test.myPrice = 100;
                              }
                            });
                            print(_index);
                          },
                        ),
                      ),
                      Text(myCart[index].itemQuantity.toString()),
                      IconButton(
                        icon: Icon(Icons.add),
                        onPressed: () {
                          setState(() {
                            myCart[index].itemQuantity++;
                            print(cart[index]);
                          });
                        },
                      ),
                      Spacer(),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          (myCart[index].itemQuantity * myCart[index].itemPrice)
                              .toString(),
                          style: TextStyle(fontSize: 18),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget proceeds(Proceed proceed, BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(left: 4.0, right: 4),
        child: Container(
          width: double.infinity,
          height: height * 0.1,
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(3), topRight: Radius.circular(3))),
          child: Card(
            elevation: 20,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Delivery Area',
                        style: TextStyle(fontSize: 20),
                      ),
                      Text(
                        proceed.deliveryarea,
                        style: TextStyle(
                            fontSize: 20,
                            decoration: TextDecoration.underline,
                            decorationColor: Colors.black87,
                            decorationThickness: 2),
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 10, top: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Subtotal',
                        style: TextStyle(fontSize: 15),
                      ),
                      Text(
                        proceed.subtotal.toString(),
                        style: TextStyle(fontSize: 15),
                      )
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 10, top: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      RichText(
                        text: TextSpan(children: [
                          TextSpan(
                              text: 'GST',
                              style: TextStyle(color: Colors.black)),
                          WidgetSpan(
                            child: Transform.translate(
                              offset: const Offset(1, 1),
                              child: Text(
                                '(16%)',
                                //superscript is usually smaller in size
                                textScaleFactor: 0.7,
                                style: TextStyle(color: Colors.black),
                              ),
                            ),
                          )
                        ]),
                      ),
                      Text(proceed.gst.toString())
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 10, top: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Delivery  Charges'),
                      Text(proceed.deliverycharges.toString())
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 10, top: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [Text('Total'), Text(proceed.total.toString())],
                  ),
                ),
                Spacer(),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: 50,
                    child: RaisedButton(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: Colors.indigo,
                      onPressed: () {

                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    CheckOutFrom.name(AddOrders(
                                      shopId: 1,
                                      metaData: MetaDataOrder(orderDetails: Test.myCart),
                                      orderStatus: "pending",
                                      orderInstruction: "testing Raja",
                                      grandTotal: 800,
                                      couponId: 1,
                                      deliveryZoneId: 1,
                                      address: "Hello World",
                                      couponDiscount: 20,
                                      deliveryCharges: 200,
                                    ))));
                      },
                      child: Text(
                        'Proceed to Checkout',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class Mycart {
  String name;
  int Price;
  int Quantity;

  Mycart(this.name, this.Price, this.Quantity);

  static List<Mycart> getcart() => [];
}

class Proceed {
  String deliveryarea;
  int subtotal;
  int deliverycharges;
  int total;

  int gst;

  Proceed(this.deliveryarea, this.subtotal, this.deliverycharges, this.total,
      this.gst);

  static List<Proceed> getproceed() => [
        Proceed('areaname', 100, 20, 500, 000),
      ];
}
