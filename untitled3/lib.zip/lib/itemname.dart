import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled3/carteilmodel.dart';

import 'package:untitled3/model.dart';
import 'package:untitled3/viewcart.dart';

import 'package:untitled3/TestList.dart';
import 'Getcartitems.dart';
import 'MyCart.dart';
import 'carteilmodel.dart';
import 'main.dart';

class Itemsnames extends StatefulWidget {
  List<Products> products_list;

  Itemsnames();

  Itemsnames.product(this.products_list);

  @override
  _ItemsnamesState createState() => _ItemsnamesState.product(products_list);
}

class _ItemsnamesState extends State<Itemsnames> {
  List<Products> products_list;

  List<User> users;
  User selectedUser;

  _ItemsnamesState.product(this.products_list);

  @override
  void initState() {
    super.initState();
    users = User.getUsers();
  }

  setSelectedUser(User user) {
    setState(() {
      selectedUser = user;
    });
  }

  // List<Widget> createRadioListUsers() {
  //   List<Widget> widgets = [];
  //   for (User user in users) {
  //     widgets.add(
  //       RadioListTile(
  //         value: user,
  //         groupValue: selectedUser,
  //         title: Text(user.firstName),
  //         subtitle: Text(user.lastName),
  //         onChanged: (currentUser) {
  //           setState(() => selectedUser == currentUser);
  //           print("Current User ${currentUser.firstName}");
  //           setSelectedUser(currentUser);
  //         },
  //         selected: selectedUser == user,
  //         activeColor: Colors.green,
  //       ),
  //     );
  //   }
  //   return widgets;
  // }

  static List<Menumodel> menunames = Menumodel.getimae();

  _ItemsnamesState();

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery
        .of(context)
        .size
        .width;
    // var height = MediaQuery.of(context).size.height;
    return Scaffold(
        body: Column(
          children: [
            Expanded(
              child: Container(
                height: MediaQuery
                    .of(context)
                    .size
                    .height - 10,
                child: GridView.count(
                  childAspectRatio: (width / 600),
                  crossAxisCount: 2,
                  children: List.generate(products_list.length, (int index) {
                    return Container(
                        width: MediaQuery
                            .of(context)
                            .size
                            .width,
                        child: cards(products_list, context, index));
                  }),
                ),
              ),
            ),
            OutlineButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (BuildContext context) =>
                            Cart.name(Test.getCart(), products_list)));
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(Icons.shopping_bag_rounded),
                  Text('CART'),
                  Text('Rs:10')
                ],
              ),
            )
          ],
        ));
  }

  Widget cards(List<Products> products_list, BuildContext context, int index) {
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: InkWell(
        child: Card(
          elevation: 5,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Flexible(
                flex: 3,
                child: Container(
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    height: MediaQuery
                        .of(context)
                        .size
                        .height,
                    child: Image.network(
                        'http://cartelapi.textiledigitizing.com/' +
                            products_list[index].itemImagePath +
                            products_list[index].itemImageName)),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(products_list[index].itemTitle),
              ),
              Padding(
                padding: const EdgeInsets.all(2.0),
                child: Text(
                  products_list[index].itemDescription,
                  maxLines: 2,
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 6.0, left: 4),
                    child: Text(
                      products_list[index].oldPrice,
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          decoration: TextDecoration.lineThrough,
                          decorationColor: Colors.red),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 6.0, left: 4),
                    child: Text(Test.myPrice.toString(),
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        )),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6.0, right: 4),
                    child: InkWell(
                      child: Container(
                          width: 30,
                          height: 30,
                          decoration: BoxDecoration(
                              color: Colors.black,
                              borderRadius: BorderRadius.circular(5)),
                          child: Center(
                              child: products_list[index].isSelected
                                  ? addicon()
                                  : minusadd())),
                      onTap: () {
                        setState(() {
                          if (products_list[index].isSelected =
                          !products_list[index].isSelected) {
                            Test.setMyCart(OrderDetails(
                                itemId: products_list[index].itemId,
                                itemPrice: int.parse(
                                    products_list[index].price),
                                itemName: products_list[index].itemTitle,
                                itemInstruction: products_list[index]
                                    .itemDescription,
                                itemQuantity: 1
                            ));
                          }
                          else {
                            Test.remvoveMyCart(OrderDetails(
                                itemId: products_list[index].itemId,
                                itemPrice: int.parse(
                                    products_list[index].price),
                                itemName: products_list[index].itemTitle,
                                itemInstruction: products_list[index]
                                    .itemDescription,
                                itemQuantity: 1
                            ));
                            products_list[index].isSelected ? false : addicon();
                          }
                        });
                        print(Test
                            .getCart()
                            .length);
                        // print(models[index].press);
                      },
                    ),
                  )
                ],
              )
            ],
          ),
        ),
        onTap: () {
          if (products_list[index].metaData != null) {
            Dialog();
          } else {
            print("Test");
          }

          // showDialog(context: null)
          //showDialog(context:context, Dialog());
        },
      ),
    );
  }

  Icon minusadd() {
    return Icon(
      Icons.add,
      color: Colors.white,
    );
  }

  Icon addicon() {
    return Icon(
      Icons.check,
      color: Colors.white,
    );
  }

  Text text() {
    return Text(
      '+',
      style: TextStyle(
          fontSize: 25, color: Colors.white, fontWeight: FontWeight.bold),
    );
  }

  Widget Dialog() {
    showGeneralDialog(
        context: context,
        barrierDismissible: false,
        barrierColor: Colors.black,
        pageBuilder: (BuildContext buildcontext, Animation animation,
            Animation secondaryanimation) {
          return Scaffold(
            body: Padding(
              padding: const EdgeInsets.only(right: 15, left: 15, top: 40),
              child: SingleChildScrollView(
                child: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(width: 1, color: Colors.white),
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Deal 01',
                                style: TextStyle(fontSize: 20),
                              ),
                            ),
                            IconButton(
                              icon: Icon(Icons.clear),
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              iconSize: 16,
                            )
                          ],
                        ),
                        Divider(
                          thickness: 1,
                          color: Colors.black,
                        ),
                        Center(
                            child: Text(
                              'All items',
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.bold),
                            )),
                        RadioWidgetDemo(),
                        Text(
                          'Others Item',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        Radiolist2(),
                        Center(
                            child: Text(
                              'Special Instruction',
                              style: TextStyle(
                                  fontSize: 25, fontWeight: FontWeight.bold),
                            )),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextField(
                            decoration: InputDecoration(
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.black12),
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide(
                                      width: 1, color: Colors.black12),
                                ),
                                hintText:
                                'you can write down here any special instruction'),
                          ),
                        ),
                        RaisedButton(
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    Itemsnames()));
                          },
                          child: Text('submit'),
                        )
                      ],
                    )),
              ),
            ),
          );
        });
  }
}

class User {
  int userId;
  String firstName;
  String lastName;

  User({this.userId, this.firstName, this.lastName});

  static List<User> getUsers() {
    return <User>[
      User(userId: 1, firstName: "Aaron", lastName: "Jackson"),
      User(userId: 2, firstName: "Ben", lastName: "John"),
      User(userId: 3, firstName: "Carrie", lastName: "Brown"),
      User(userId: 4, firstName: "Deep", lastName: "Sen"),
      User(userId: 5, firstName: "Emily", lastName: "Jane"),
    ];
  }
}
